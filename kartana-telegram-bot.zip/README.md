# Kartana Telegram Bot

AI companion Telegram bot for trading tasks.